wc -l $1
